<?php
/**
 * The template for displaying the footer — 6-column grid matching wordiva.ai
 *
 * @package Wordiva_Theme
 * @since 2.0.0
 */

$is_blog_context = is_home() || is_singular('post') || is_archive() || is_search();
$wordiva_footer_columns = function_exists('wordiva_get_footer_links') ? wordiva_get_footer_links() : array();
$wordiva_footer_legal = function_exists('wordiva_get_footer_legal_links') ? wordiva_get_footer_legal_links() : array();
?>

    </div><!-- .site-content -->
    
    <footer class="site-footer" role="contentinfo" id="site-footer">
        <div class="footer-content">
            <div class="container">
                <div class="wordiva-footer-grid">
                    
                    <!-- Brand + Social Links -->
                    <div class="footer-brand-section">
                        <?php wordiva_render_logo('footer-logo'); ?>
                        <p class="footer-tagline"><?php esc_html_e('Agentic AI content marketing on autopilot.', 'wordiva-blog-theme'); ?></p>
                        <div class="social-links">
                            <a href="<?php echo esc_url(get_theme_mod('wordiva_twitter_url', 'https://x.com/wordivaai')); ?>"
                               target="_blank"
                               rel="noopener noreferrer"
                               aria-label="<?php esc_attr_e('Follow Wordiva on X', 'wordiva-blog-theme'); ?>"
                               class="social-link">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                                </svg>
                            </a>
                            <a href="<?php echo esc_url(get_theme_mod('wordiva_youtube_url', 'https://www.youtube.com/@wordivaai')); ?>" 
                               target="_blank" 
                               rel="noopener noreferrer" 
                               aria-label="<?php esc_attr_e('Follow Wordiva on YouTube', 'wordiva-blog-theme'); ?>"
                               class="social-link">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                                </svg>
                            </a>
                            <a href="<?php echo esc_url(get_theme_mod('wordiva_facebook_url', 'https://www.facebook.com/wordivaai/')); ?>" 
                               target="_blank" 
                               rel="noopener noreferrer" 
                               aria-label="<?php esc_attr_e('Follow Wordiva on Facebook', 'wordiva-blog-theme'); ?>"
                               class="social-link">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                                </svg>
                            </a>
                            <a href="<?php echo esc_url(get_theme_mod('wordiva_linkedin_url', 'https://www.linkedin.com/company/wordiva-ai/')); ?>" 
                               target="_blank" 
                               rel="noopener noreferrer" 
                               aria-label="<?php esc_attr_e('Follow Wordiva on LinkedIn', 'wordiva-blog-theme'); ?>"
                               class="social-link">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                                </svg>
                            </a>
                            <a href="<?php echo esc_url(get_theme_mod('wordiva_instagram_url', 'https://www.instagram.com/wordivaai/')); ?>" 
                               target="_blank" 
                               rel="noopener noreferrer" 
                               aria-label="<?php esc_attr_e('Follow Wordiva on Instagram', 'wordiva-blog-theme'); ?>"
                               class="social-link">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                                </svg>
                            </a>
                        </div>
                    </div>
                    
                    <!-- Link columns -->
                    <?php foreach ($wordiva_footer_columns as $column_label => $links) : ?>
                        <nav class="wordiva-footer-col" aria-label="<?php echo esc_attr($column_label); ?>">
                            <h3 class="wordiva-footer-col-title"><?php echo esc_html($column_label); ?></h3>
                            <ul class="wordiva-footer-col-list">
                                <?php foreach ($links as $link) : ?>
                                    <li>
                                        <a href="<?php echo esc_url($link['href']); ?>" class="wordiva-footer-link <?php echo (!empty($link['active_blog']) && $is_blog_context) ? 'active' : ''; ?>">
                                            <?php echo esc_html($link['label']); ?>
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </nav>
                    <?php endforeach; ?>
                    
                </div>
            </div>
        </div>
        
        <div class="footer-bottom">
            <div class="container">
                <div class="footer-bottom-content">
                    <p class="copyright">
                        &copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. <?php esc_html_e('All rights reserved.', 'wordiva-blog-theme'); ?>
                    </p>
                    <nav class="wordiva-footer-legal" aria-label="<?php esc_attr_e('Legal Navigation', 'wordiva-blog-theme'); ?>">
                        <?php foreach ($wordiva_footer_legal as $link) : ?>
                            <a href="<?php echo esc_url($link['href']); ?>" class="wordiva-footer-link"><?php echo esc_html($link['label']); ?></a>
                        <?php endforeach; ?>
                    </nav>
                </div>
            </div>
        </div>
    </footer>
    
</div><!-- .site-wrapper -->

<?php wp_footer(); ?>
</body>
</html>
